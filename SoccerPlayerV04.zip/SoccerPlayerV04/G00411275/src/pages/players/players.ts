import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SportProvider } from '../../providers/sport/sport';
import { Storage } from "@ionic/storage";

/**
 * Generated class for the PlayersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-players',
  templateUrl: 'players.html',
})
export class PlayersPage {

  myCountryID: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, private sp: SportProvider, private storage: Storage) {

    this.readPlayers()
  }

  readPlayers() {
    this.storage.get("dataSettings")
      .then((val) => {
        const countryID = val.Dt_countryID
        const minAge = val.Dt_minAge
        const maxAge = val.Dt_maxAge
        console.log(">>> DADOS <<<");
        console.log(countryID);
        console.log(minAge);
        console.log(maxAge);

        this.myCountryID = countryID;

        var res = this.sp.getPlayers(countryID, minAge, maxAge);
        console.log(">>> RESPOSTA <<<");
        console.log(res);


      });
  }

}
